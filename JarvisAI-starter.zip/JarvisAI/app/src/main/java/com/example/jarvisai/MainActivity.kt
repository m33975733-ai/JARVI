package com.example.jarvisai

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val voiceRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("Jarvis", "Assalam-o-alaikum! Main Jarvis AI ka starter version hoon. Text ya mic se command dein. Abhi basic commands offline chalti hain.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
            setBackgroundColor(0xFFF4F6FC.toInt())
        }
        val title = TextView(this).apply {
            text = "JARVIS AI"
            textSize = 25f
            setTextColor(0xFF17264B.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(2, 4, 2, 12) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Command likhein..."
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(16, 8, 16, 8)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendInput(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, 56, 1f))
        val send = Button(this).apply { text = "Send"; setOnClickListener { sendInput() } }
        row.addView(send)
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        val mic = Button(this).apply {
            text = "🎙  Voice command"
            setOnClickListener { startVoiceInput() }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun sendInput() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addMessage("You", text)
        handleCommand(text)
    }

    private fun handleCommand(raw: String) {
        val s = raw.lowercase(Locale.ROOT)
        when {
            s.contains("wifi") || s.contains("wi-fi") -> reply("Wi-Fi settings khol raha hoon. Wahan se network select karein.") { openSettings("android.settings.WIFI_SETTINGS") }
            s.contains("bluetooth") -> reply("Bluetooth settings khol raha hoon.") { openSettings("android.settings.BLUETOOTH_SETTINGS") }
            s.contains("settings") -> reply("Phone settings khol raha hoon.") { openSettings("android.settings.SETTINGS") }
            s.contains("youtube") -> reply("YouTube khol raha hoon.") { launchPackage("com.google.android.youtube", "https://www.youtube.com") }
            s.contains("whatsapp") -> reply("WhatsApp khol raha hoon.") { launchPackage("com.whatsapp", "https://www.whatsapp.com") }
            s.contains("chrome") || s.contains("browser") || s.contains("internet") -> reply("Browser khol raha hoon.") { launchPackage("com.android.chrome", "https://www.google.com") }
            s.startsWith("search ") || s.startsWith("google ") || s.startsWith("search for ") -> {
                val q = raw.substringAfter(' ').trim().ifBlank { raw }
                reply("Web par search kar raha hoon: $q") { openUrl("https://www.google.com/search?q=" + Uri.encode(q)) }
            }
            s.contains("time") -> respond("Mujhe abhi phone ka exact time read karne ka feature aglay version mein add karna hai. Filhal status bar dekhein.")
            s.contains("hello") || s.contains("salam") || s.contains("assalam") -> respond("Wa-alaikum-assalam! Batayein, kya karna hai?")
            s.contains("help") || s.contains("madad") || s.contains("commands") -> respond("Abhi yeh commands try karein: Wi-Fi, Bluetooth, Settings, YouTube, WhatsApp, Browser, Search [topic]. Full AI planning aur zyada phone controls aglay phase mein add honge.")
            else -> respond("Yeh starter version abhi is command ko samajh nahi saka. Try karein: 'Wi-Fi settings kholo', 'YouTube kholo', ya 'Search Pakistan weather'. Online AI brain abhi connect nahi hai.")
        }
    }

    private fun reply(message: String, action: () -> Unit) {
        respond(message)
        try { action() } catch (_: Exception) { Toast.makeText(this, "Yeh action is phone par available nahi hai.", Toast.LENGTH_SHORT).show() }
    }

    private fun respond(text: String) { addMessage("Jarvis", text); if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }

    private fun addMessage(who: String, text: String) {
        val bubble = TextView(this).apply {
            this.text = "$who:  $text"
            textSize = 16f
            setTextColor(if (who == "Jarvis") 0xFF17264B.toInt() else 0xFF202020.toInt())
            setBackgroundColor(if (who == "Jarvis") 0xFFFFFFFF.toInt() else 0xFFE3EBFF.toInt())
            setPadding(16, 14, 16, 14)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
        chat.addView(bubble, lp)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis ko command bol kar dein")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Is phone par voice recognition service nahi mili.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); sendInput() }
        }
    }

    private fun openSettings(action: String) { startActivity(Intent(action)) }
    private fun openUrl(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    private fun launchPackage(pkg: String, fallback: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch) else openUrl(fallback)
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("ur", "PK") }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
