# Jarvis AI — Android starter project

This is a small Android Studio starter app for a Samsung Galaxy A51 / Android 13. It includes a chat screen, Android speech recognition, text-to-speech, and a few explicit commands that open apps or system settings.

## Build it
1. Install Android Studio on a computer.
2. Open this `JarvisAI` folder as a project.
3. Let Gradle sync. Use JDK 17 and Android SDK 35 if prompted.
4. Connect the phone with USB debugging enabled, or use Build > Build APK(s).
5. On first launch, grant microphone permission if Android asks. Voice recognition may require internet and Google's speech service.

## Commands in this starter
- `Wi-Fi` / `Wi-Fi settings`
- `Bluetooth`
- `Settings`
- `YouTube`, `WhatsApp`, `Browser`
- `Search [topic]`

## Important limits
- This is a starter prototype, not a complete autonomous agent and not yet connected to an online AI model.
- Android intentionally blocks apps from silently controlling many protected settings. This app opens the relevant settings screen instead of secretly changing them.
- A real online AI brain should be connected through a small secure backend; do not put private API keys directly inside an APK.
- Offline AI requires a compatible on-device model and can be slower or memory-heavy on older phones. That is a later phase.
- Before adding actions that send messages, delete data, spend money, or change security settings, the app should ask for confirmation.
